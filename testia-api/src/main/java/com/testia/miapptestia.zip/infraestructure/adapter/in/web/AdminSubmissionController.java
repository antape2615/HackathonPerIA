package com.testia.infraestructure.adapter.in.web;

import com.testia.application.dto.AdminSubmissionDetailResponse;
import com.testia.application.dto.AdminSubmissionListItem;
import com.testia.application.service.AiEvaluationService;
import com.testia.application.service.SubmissionQueryService;
import com.testia.domain.exception.DomainException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/submissions")   // 🔥 RUTA CORRECTA
public class AdminSubmissionController {

    private final SubmissionQueryService queryService;
    private final AiEvaluationService aiService;

    public AdminSubmissionController(
            SubmissionQueryService queryService,
            AiEvaluationService aiService
    ) {
        this.queryService = queryService;
        this.aiService = aiService;
    }

    // ------------------------------------------------------------
    // LISTAR SUBMISSIONS
    // GET /api/v1/admin/submission
    // ------------------------------------------------------------
    @GetMapping
    public ResponseEntity<List<AdminSubmissionListItem>> listAll() {
        return ResponseEntity.ok(queryService.getAllSubmissions());
    }

    // ------------------------------------------------------------
    // DETALLE DE UN SUBMISSION
    // GET /api/v1/admin/submission/{submissionId}
    // ------------------------------------------------------------
    @GetMapping("/{submissionId}")
    public ResponseEntity<?> getSubmissionDetails(
            @PathVariable("submissionId") String submissionId
    ) {
        try {
            AdminSubmissionDetailResponse response =
                    queryService.getSubmissionDetails(submissionId);

            return ResponseEntity.ok(response);

        } catch (DomainException ex) {
            return ResponseEntity
                    .status(ex.getStatus())
                    .body(ex.getMessage());
        }
    }

    // ------------------------------------------------------------
    // RE-EVALUAR POR IA
    // POST /api/v1/admin/submission/{submissionId}/refresh
    // ------------------------------------------------------------
    @PostMapping("/{submissionId}/refresh")
    public ResponseEntity<?> refreshEvaluation(
            @PathVariable("submissionId") String submissionId
    ) {
        try {
            return ResponseEntity.ok(aiService.refreshEvaluation(submissionId));

        } catch (DomainException ex) {
            return ResponseEntity
                    .status(ex.getStatus())
                    .body(ex.getMessage());
        }
    }
}
