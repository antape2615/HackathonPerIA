package com.testia.application.service;

import com.testia.application.dto.AdminSubmissionDetailResponse;
import com.testia.application.dto.AdminSubmissionListItem;
import com.testia.domain.exception.DomainException;
import com.testia.domain.model.AssignedTest;
import com.testia.domain.model.CandidateSubmission;
import com.testia.domain.model.EvaluationResult;
import com.testia.domain.port.AssignedTestRepositoryPort;
import com.testia.domain.port.CandidateSubmissionRepositoryPort;
import com.testia.domain.port.EvaluationResultRepositoryPort;
import com.testia.infraestructure.adapter.out.db.entity.CandidateSubmissionEntity;
import com.testia.infraestructure.adapter.out.db.mapper.CandidateSubmissionMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class SubmissionQueryService {

    private final CandidateSubmissionRepositoryPort submissionRepo;
    private final AssignedTestRepositoryPort assignmentRepo;
    private final EvaluationResultRepositoryPort evalRepo;

    public SubmissionQueryService(
            CandidateSubmissionRepositoryPort submissionRepo,
            AssignedTestRepositoryPort assignmentRepo,
            EvaluationResultRepositoryPort evalRepo
    ) {
        this.submissionRepo = submissionRepo;
        this.assignmentRepo = assignmentRepo;
        this.evalRepo = evalRepo;
    }

    // --------------------------------------------------------
    // LISTAR SUBMISSIONS
    // --------------------------------------------------------
    public List<AdminSubmissionListItem> getAllSubmissions() {

        // Tu port retorna ENTITIES
        List<CandidateSubmissionEntity> entities = submissionRepo.findAll();

        return entities.stream()
                .map(entity -> {

                    CandidateSubmission s = CandidateSubmissionMapper.toDomain(entity);

                    // Buscar assignment asociado
                    AssignedTest assignment = assignmentRepo.findById(s.getAssignmentId()).orElse(null);

                    // Buscar evaluación asociada
                    EvaluationResult eval = evalRepo.findByAssignmentId(s.getAssignmentId()).orElse(null);

                    Integer score = eval != null
                            ? (int) Math.round(eval.getOverallScore())
                            : null;

                    // Derivamos STATUS → basado en si tiene evaluación o no
                    String submissionStatus = (eval != null) ? "COMPLETED" : "SUBMITTED";

                    return new AdminSubmissionListItem(
                            s.getId().toString(),                       // submissionId ✔
                            s.getCandidateEmail(),                      // candidateEmail
                            assignment != null ? assignment.getTestId().toString() : null,
                            submissionStatus,                           // 🔥 status FIJO
                            score,                                      // score
                            s.getSubmittedAt()                          // submittedAt
                    );
                })
                .collect(Collectors.toList());
    }

    // --------------------------------------------------------
    // DETALLE COMPLETO POR submissionId
    // --------------------------------------------------------
    public AdminSubmissionDetailResponse getSubmissionDetails(String submissionId) {

        // 🔥 Protección anti null / undefined
        if (submissionId == null || submissionId.isBlank() || submissionId.equals("undefined")) {
            throw new DomainException("Invalid submissionId", HttpStatus.BAD_REQUEST);
        }

        UUID id;
        try {
            id = UUID.fromString(submissionId);
        } catch (Exception e) {
            throw new DomainException("Invalid UUID format", HttpStatus.BAD_REQUEST);
        }

        // Buscar submission (workaround findAll())
        CandidateSubmission submission = submissionRepo.findAll().stream()
                .map(CandidateSubmissionMapper::toDomain)
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new DomainException("Submission not found", HttpStatus.NOT_FOUND));

        // Obtener assignment
        AssignedTest assignment = assignmentRepo.findById(submission.getAssignmentId())
                .orElseThrow(() -> new DomainException("Assignment not found", HttpStatus.NOT_FOUND));

        // Obtener evaluación
        EvaluationResult eval = evalRepo.findByAssignmentId(assignment.getId())
                .orElseThrow(() -> new DomainException("Evaluation not found", HttpStatus.NOT_FOUND));

        // Armar respuesta
        return new AdminSubmissionDetailResponse(
                submission.getId().toString(),
                submission.getCandidateEmail(),
                assignment.getTestId().toString(),
                submission.getSubmittedCode(),
                submission.getSubmittedAt(),
                (int) Math.round(eval.getOverallScore()),
                eval.getBucketScores(),
                eval.getBigOTime(),
                eval.getBigOSpace(),
                eval.getLineCount(),
                eval.getEdgeCaseCoverage(),
                eval.getSecurityNotes(),
                eval.getGlobalSummary(),
                eval.getEvaluatedAt()
        );
    }
}
